import sys

from PySide6.QtCore import QUrl
from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
)

from PySide6.QtWebEngineWidgets import QWebEngineView


class MyBrowser(QMainWindow):

    def __init__(self):

        super().__init__()

        # -----------------------------------------
        # WINDOW
        # -----------------------------------------

        self.setWindowTitle("My Browser")

        self.resize(1200, 800)


        # -----------------------------------------
        # MAIN WIDGET
        # -----------------------------------------

        central_widget = QWidget()

        self.setCentralWidget(
            central_widget
        )


        # -----------------------------------------
        # MAIN LAYOUT
        # -----------------------------------------

        main_layout = QVBoxLayout(
            central_widget
        )

        main_layout.setContentsMargins(
            0, 0, 0, 0
        )


        # -----------------------------------------
        # TOOLBAR
        # -----------------------------------------

        toolbar = QHBoxLayout()


        # Back
        self.back_button = QPushButton("←")

        self.back_button.clicked.connect(
            self.go_back
        )


        # Forward
        self.forward_button = QPushButton("→")

        self.forward_button.clicked.connect(
            self.go_forward
        )


        # Reload
        self.reload_button = QPushButton("⟳")

        self.reload_button.clicked.connect(
            self.reload_page
        )


        # Search / URL bar
        self.address_bar = QLineEdit()

        self.address_bar.setPlaceholderText(
            "Search or enter URL..."
        )

        self.address_bar.returnPressed.connect(
            self.navigate
        )


        # Go button
        self.go_button = QPushButton("GO")

        self.go_button.clicked.connect(
            self.navigate
        )


        # Add controls
        toolbar.addWidget(
            self.back_button
        )

        toolbar.addWidget(
            self.forward_button
        )

        toolbar.addWidget(
            self.reload_button
        )

        toolbar.addWidget(
            self.address_bar
        )

        toolbar.addWidget(
            self.go_button
        )


        main_layout.addLayout(
            toolbar
        )


        # -----------------------------------------
        # WEB ENGINE
        # -----------------------------------------

        self.web_view = QWebEngineView()

        main_layout.addWidget(
            self.web_view
        )


        # -----------------------------------------
        # PAGE EVENTS
        # -----------------------------------------

        self.web_view.urlChanged.connect(
            self.url_changed
        )

        self.web_view.titleChanged.connect(
            self.title_changed
        )


        # -----------------------------------------
        # START PAGE
        # -----------------------------------------

        self.web_view.setUrl(
            QUrl("https://example.com")
        )


    # =============================================
    # NAVIGATION
    # =============================================

    def navigate(self):

        text = self.address_bar.text().strip()

        if not text:

            return


        # -----------------------------------------
        # URL
        # -----------------------------------------

        if (
            text.startswith("http://")
            or
            text.startswith("https://")
        ):

            url = text


        # -----------------------------------------
        # Domain
        # -----------------------------------------

        elif "." in text and " " not in text:

            url = "https://" + text


        # -----------------------------------------
        # SEARCH
        # -----------------------------------------

        else:

            from urllib.parse import quote

            url = (
                "https://www.google.com/search?q="
                + quote(text)
            )


        self.web_view.setUrl(
            QUrl(url)
        )


    # =============================================
    # BACK
    # =============================================

    def go_back(self):

        self.web_view.back()


    # =============================================
    # FORWARD
    # =============================================

    def go_forward(self):

        self.web_view.forward()


    # =============================================
    # RELOAD
    # =============================================

    def reload_page(self):

        self.web_view.reload()


    # =============================================
    # URL CHANGED
    # =============================================

    def url_changed(self, url):

        self.address_bar.setText(
            url.toString()
        )


    # =============================================
    # TITLE CHANGED
    # =============================================

    def title_changed(self, title):

        if title:

            self.setWindowTitle(
                title + " - My Browser"
            )

        else:

            self.setWindowTitle(
                "My Browser"
            )


# =================================================
# START APPLICATION
# =================================================

if __name__ == "__main__":

    app = QApplication(sys.argv)

    browser = MyBrowser()

    browser.show()

    sys.exit(
        app.exec()
    )