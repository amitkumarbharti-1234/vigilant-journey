
# My Browser

A minimal personal web browser.

## Current architecture

- Search / URL input
- URL detection
- Web requests
- HTML parsing
- Page rendering
- Back navigation
- Forward navigation
- Reload

## Development

The prototype was developed in Google Colab.

## Final target

Python + PySide6 + QtWebEngine on Windows.

The final browser will render:

- HTML
- CSS
- JavaScript
- Images
- Canvas
- WebGL
- Modern websites
