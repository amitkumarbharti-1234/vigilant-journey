@echo off
python -m search_engine.rebuild_index
python -m search_engine.pagerank
python -m search_engine.prioritize
pause
