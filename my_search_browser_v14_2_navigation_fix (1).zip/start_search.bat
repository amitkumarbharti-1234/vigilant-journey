@echo off
python -m search_engine.server
pause
