@echo off
python -m search_engine.frontier_cycle --pages 1000
python -m search_engine.rebuild_index
python -m search_engine.pagerank
python -m search_engine.prioritize
python -c "from search_engine.indexer import stats; print(stats())"
pause
