from .db import connect,init_db
init_db()
c=connect()
cols={r['name'] for r in c.execute('PRAGMA table_info(pages)')}
if 'h1' not in cols: c.execute("ALTER TABLE pages ADD COLUMN h1 TEXT DEFAULT ''")
c.commit(); c.close()
print("V14 database initialized/migrated.")
