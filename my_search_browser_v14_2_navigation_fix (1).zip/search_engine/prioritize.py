import time
from .db import connect,init_db
def run():
    init_db(); c=connect()
    pages=c.execute("SELECT id,depth,content_length,title FROM pages").fetchall()
    inbound={r["to_url"]:r["n"] for r in c.execute("SELECT to_url,COUNT(*) n FROM links GROUP BY to_url")}
    urls={r["id"]:r["url"] for r in c.execute("SELECT id,url FROM pages")}
    c.execute("DELETE FROM url_signals")
    for p in pages:
        titleq=min(1,len((p["title"] or ""))/60)
        out=c.execute("SELECT COUNT(*) FROM links WHERE from_id=?",(p["id"],)).fetchone()[0]
        c.execute("""INSERT INTO url_signals(page_id,inbound_links,outbound_links,text_length,title_quality,depth,updated_at)
          VALUES(?,?,?,?,?,?,?)""",(p["id"],inbound.get(urls[p["id"]],0),out,p["content_length"] or 0,titleq,p["depth"] or 0,time.time()))
    c.execute("""UPDATE url_frontier SET priority=priority+1 WHERE status='queued'""")
    c.commit(); c.close()
if __name__=="__main__":
    run(); print("Frontier priorities updated.")
