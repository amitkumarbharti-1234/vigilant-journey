DB_PATH = "search.db"
USER_AGENT = "MySearchEngineV13/1.0 (+educational crawler)"
CRAWL_TIMEOUT = 12
MAX_TEXT = 300000
MAX_RESULTS = 100
DEFAULT_SEEDS = [
    "https://example.com/",
    "https://www.iana.org/protocols",
    "https://en.wikipedia.org/wiki/Quantum_mechanics",
    "https://en.wikipedia.org/wiki/Artificial_intelligence",
    "https://en.wikipedia.org/wiki/Neural_network",
    "https://en.wikipedia.org/wiki/Physics",
    "https://en.wikipedia.org/wiki/Computer_science",
    "https://www.python.org/",
    "https://docs.python.org/3/",
    "https://developer.mozilla.org/en-US/docs/Web/JavaScript",
    "https://developer.mozilla.org/en-US/docs/Web/HTML",
    "https://developer.mozilla.org/en-US/docs/Web/CSS",
]
STOPWORDS = set("""a an and are as at be by for from has have how i in is it its of on or that the this to was were what when where which who why with you your into about over under after before can could should would will""".split())

EMBEDDING_MODEL="all-MiniLM-L6-v2"
