from .indexer import rebuild,stats
if __name__=="__main__":
    rebuild(); print("Index rebuilt:",stats())
