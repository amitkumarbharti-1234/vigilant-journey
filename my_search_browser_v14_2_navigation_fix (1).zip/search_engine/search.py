import math,re,pickle,numpy as np
from .db import connect,init_db
from .text import useful_tokens,phrase_bonus
from .config import EMBEDDING_MODEL

_MODEL=None
def get_model():
    global _MODEL
    if _MODEL is None:
        from sentence_transformers import SentenceTransformer
        _MODEL=SentenceTransformer(EMBEDDING_MODEL)
    return _MODEL

def bm25(tf,dl,avdl,df,N,k1=1.5,b=.75):
    idf=math.log(1+(N-df+.5)/(df+.5))
    return idf*(tf*(k1+1))/(tf+k1*(1-b+b*dl/max(avdl,1)))

def search(query,page=1,per_page=20):
    init_db()
    c=connect()
    qterms=list(dict.fromkeys(useful_tokens(query)))
    if not qterms:
        return [],0

    ph=",".join("?"*len(qterms))
    trs=c.execute(f"SELECT id,term,df FROM terms WHERE term IN ({ph})",qterms).fetchall()
    if not trs:
        return [],0

    N=c.execute("SELECT COUNT(*) FROM pages").fetchone()[0] or 1
    avdl=c.execute("SELECT COALESCE(AVG(content_length),1) FROM pages").fetchone()[0] or 1
    scores={}

    # BM25 candidate retrieval from body.
    for tr in trs:
        for r in c.execute(
            "SELECT p.id,p.content_length,po.tf FROM postings po "
            "JOIN pages p ON p.id=po.page_id WHERE po.term_id=?",(tr["id"],)):
            scores[r["id"]]=scores.get(r["id"],0)+bm25(
                r["tf"],r["content_length"],avdl,max(1,tr["df"]),N)

    rows=c.execute("""SELECT p.*,COALESCE(pr.score,0) pr,
        COALESCE(us.inbound_links,0) inbound,e.vector
        FROM pages p
        LEFT JOIN pagerank pr ON p.id=pr.page_id
        LEFT JOIN url_signals us ON p.id=us.page_id
        LEFT JOIN embeddings e ON p.id=e.page_id""").fetchall()

    semantic={}
    if any(r["vector"] is not None for r in rows):
        qv=get_model().encode([query],normalize_embeddings=True)[0]
        for r in rows:
            if r["vector"] is not None:
                try:
                    v=np.asarray(pickle.loads(r["vector"]),dtype=np.float32)
                except Exception:
                    raw=r["vector"]
                    if raw is None or len(raw)%4 != 0:
                        continue
                    v=np.frombuffer(raw,dtype=np.float32)
                if v.ndim != 1 or v.size != qv.size:
                    continue
                semantic[r["id"]]=float(np.dot(qv,v))
                if semantic[r["id"]] >= .20:
                    scores.setdefault(r["id"],0.0)

    for r in rows:
        if r["id"] not in scores:
            continue
        s=scores[r["id"]]
        title=" ".join(useful_tokens(r["title"] or ""))
        h1=" ".join(useful_tokens(r["h1"] or ""))
        url=" ".join(useful_tokens((r["url"] or "").replace("/"," ")))

        # Field weighting.
        for t in qterms:
            if re.search(r"\b"+re.escape(t)+r"\b",title): s+=5.0
            if re.search(r"\b"+re.escape(t)+r"\b",h1): s+=3.5
            if re.search(r"\b"+re.escape(t)+r"\b",url): s+=2.0

        s += 2.0*phrase_bonus(r["title"],query)
        s += 1.2*phrase_bonus(r["h1"],query)
        s += phrase_bonus(r["text"],query)
        s += min(4.0,math.log1p(r["inbound"] or 0))*0.8

        # PageRank quality signal.
        s += min(3.0,(r["pr"] or 0)*100)

        # Semantic contribution.
        s += max(0.0,semantic.get(r["id"],0.0))*12.0
        scores[r["id"]]=s

    ranked=sorted(
        [r for r in rows if r["id"] in scores],
        key=lambda r:scores[r["id"]],reverse=True)

    total=len(ranked)
    start=(page-1)*per_page
    out=[]
    for r in ranked[start:start+per_page]:
        text=r["text"] or ""
        low=text.lower()
        positions=[low.find(t) for t in qterms if low.find(t)>=0]
        i=min(positions) if positions else 0
        a=max(0,i-120); b=min(len(text),i+300)
        snippet=text[a:b].strip()
        if a>0: snippet="…"+snippet
        if b<len(text): snippet+="…"
        out.append({
            "title":r["title"] or r["url"],
            "url":r["url"],
            "snippet":snippet,
            "score":round(scores[r["id"]],3),
            "semantic_similarity":round(semantic.get(r["id"],0.0),4)
        })
    c.close()
    return out,total
