import sqlite3
from .config import DB_PATH

def connect():
    c=sqlite3.connect(DB_PATH)
    c.row_factory=sqlite3.Row
    return c

def init_db():
    c=connect(); q=c.cursor()
    q.executescript("""
    CREATE TABLE IF NOT EXISTS pages(
      id INTEGER PRIMARY KEY,url TEXT UNIQUE,title TEXT,h1 TEXT DEFAULT '',text TEXT,domain TEXT,
      crawled_at REAL,etag TEXT,last_modified TEXT,content_hash TEXT,
      status_code INTEGER,depth INTEGER DEFAULT 0,content_length INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS links(
      id INTEGER PRIMARY KEY,from_id INTEGER,to_url TEXT,anchor TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS terms(
      id INTEGER PRIMARY KEY,term TEXT UNIQUE,df INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS postings(
      term_id INTEGER,page_id INTEGER,tf INTEGER DEFAULT 0,PRIMARY KEY(term_id,page_id)
    );
    CREATE TABLE IF NOT EXISTS anchor_postings(
      term_id INTEGER,page_id INTEGER,tf INTEGER DEFAULT 0,PRIMARY KEY(term_id,page_id)
    );
    CREATE TABLE IF NOT EXISTS pagerank(page_id INTEGER PRIMARY KEY,score REAL);
    CREATE TABLE IF NOT EXISTS embeddings(
      page_id INTEGER PRIMARY KEY, vector BLOB NOT NULL,
      model TEXT NOT NULL, updated_at REAL
    );
    CREATE TABLE IF NOT EXISTS url_frontier(
      url TEXT PRIMARY KEY,status TEXT DEFAULT 'queued',priority REAL DEFAULT 0,
      discovered_at REAL,crawled_at REAL,next_crawl REAL,status_code INTEGER,
      error TEXT,content_hash TEXT,depth INTEGER DEFAULT 0,crawl_count INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS domain_stats(
      domain TEXT PRIMARY KEY,crawls INTEGER DEFAULT 0,successes INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS url_signals(
      page_id INTEGER PRIMARY KEY,inbound_links INTEGER DEFAULT 0,
      outbound_links INTEGER DEFAULT 0,text_length INTEGER DEFAULT 0,
      title_quality REAL DEFAULT 0,depth INTEGER DEFAULT 0,updated_at REAL
    );
    CREATE INDEX IF NOT EXISTS idx_post_term ON postings(term_id);
    CREATE INDEX IF NOT EXISTS idx_post_page ON postings(page_id);
    CREATE INDEX IF NOT EXISTS idx_anchor_term ON anchor_postings(term_id);
    CREATE INDEX IF NOT EXISTS idx_frontier_status ON url_frontier(status,next_crawl);
    """)
    c.commit(); c.close()
