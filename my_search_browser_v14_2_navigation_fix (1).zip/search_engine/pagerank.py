from collections import defaultdict
from .db import connect,init_db
def build(iterations=20,d=.85):
    init_db(); c=connect()
    rows=c.execute("SELECT id,url FROM pages").fetchall()
    ids={r["url"]:r["id"] for r in rows}; n=len(ids)
    if not n: return
    edges=defaultdict(set)
    for r in c.execute("SELECT from_id,to_url FROM links"):
        to=ids.get(r["to_url"])
        if to: edges[r["from_id"]].add(to)
    pr={i:1/n for i in ids.values()}
    for _ in range(iterations):
        new={i:(1-d)/n for i in ids.values()}
        for a,outs in edges.items():
            if not outs: continue
            share=d*pr.get(a,0)/len(outs)
            for b in outs: new[b]+=share
        pr=new
    c.execute("DELETE FROM pagerank")
    c.executemany("INSERT INTO pagerank(page_id,score) VALUES(?,?)",pr.items())
    c.commit(); c.close()
if __name__=="__main__":
    build(); print("PageRank rebuilt.")
