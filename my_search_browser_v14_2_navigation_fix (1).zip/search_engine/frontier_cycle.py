import argparse
from .crawler import crawl_cycle
if __name__=="__main__":
    p=argparse.ArgumentParser(); p.add_argument("--pages",type=int,default=250)
    a=p.parse_args(); ok,total=crawl_cycle(a.pages)
    print(f"Crawled {ok}/{total} frontier URLs successfully.")
