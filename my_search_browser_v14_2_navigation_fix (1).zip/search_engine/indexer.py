import math,re
from .db import connect,init_db
from .text import useful_tokens
def rebuild():
    init_db(); c=connect()
    c.execute("DELETE FROM postings"); c.execute("DELETE FROM anchor_postings"); c.execute("DELETE FROM terms")
    pages=c.execute("SELECT id,title,text FROM pages").fetchall()
    term_cache={}
    for p in pages:
        counts={}
        for t in useful_tokens((p["title"]+" ")*4+" "+(p["text"] or "")): counts[t]=counts.get(t,0)+1
        for t,tf in counts.items():
            if t not in term_cache:
                cur=c.execute("INSERT INTO terms(term,df) VALUES(?,0)",(t,)); term_cache[t]=cur.lastrowid
            c.execute("INSERT INTO postings(term_id,page_id,tf) VALUES(?,?,?)",(term_cache[t],p["id"],tf))
    links=c.execute("SELECT to_url,anchor FROM links").fetchall()
    url_ids={r["url"]:r["id"] for r in c.execute("SELECT id,url FROM pages")}
    for to,anchor in links:
        pid=url_ids.get(to)
        if not pid: continue
        counts={}
        for t in useful_tokens(anchor): counts[t]=counts.get(t,0)+1
        for t,tf in counts.items():
            if t in term_cache:
                c.execute("INSERT INTO anchor_postings(term_id,page_id,tf) VALUES(?,?,?) ON CONFLICT(term_id,page_id) DO UPDATE SET tf=tf+excluded.tf",(term_cache[t],pid,tf))
    for t,tid in term_cache.items():
        df=c.execute("SELECT COUNT(*) FROM postings WHERE term_id=?",(tid,)).fetchone()[0]
        c.execute("UPDATE terms SET df=? WHERE id=?",(df,tid))
    c.commit(); c.close()
def stats():
    c=connect()
    out={}
    for table,key in [("pages","pages"),("terms","terms"),("postings","postings"),("links","links"),("url_frontier","frontier")]:
        out[key]=c.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
    c.close(); return out
if __name__=="__main__":
    rebuild(); print("Index rebuilt:",stats())
