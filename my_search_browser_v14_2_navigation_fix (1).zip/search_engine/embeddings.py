import time,pickle,numpy as np
from .db import connect,init_db
from .config import EMBEDDING_MODEL

def build_embeddings():
    init_db()
    c=connect()
    rows=c.execute("SELECT id,title,h1,text FROM pages").fetchall()
    if not rows:
        print("No pages to embed.")
        c.close()
        return
    from sentence_transformers import SentenceTransformer
    model=SentenceTransformer(EMBEDDING_MODEL)
    texts=[f"{r["title"] or ""}. {r["h1"] or ""}. {r["text"] or ""}"[:12000] for r in rows]
    vecs=model.encode(texts,normalize_embeddings=True,show_progress_bar=True)
    c.execute("DELETE FROM embeddings")
    now=time.time()
    c.executemany("INSERT INTO embeddings VALUES(?,?,?,?)",
        [(r["id"],pickle.dumps(np.asarray(v,dtype=np.float32)),EMBEDDING_MODEL,now)
         for r,v in zip(rows,vecs)])
    c.commit(); c.close()
    print(f"Built {len(rows)} semantic vectors.")
