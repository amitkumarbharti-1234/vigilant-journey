from flask import Flask,request,jsonify
import math,urllib.parse
from .search import search
from .indexer import stats
app=Flask(__name__)

CSS="""body{font-family:Arial,sans-serif;max-width:1000px;margin:0 auto;padding:24px;color:#202124}
.search{display:flex;gap:8px;margin-bottom:8px}.search input{flex:1;padding:13px 16px;font-size:18px;border:1px solid #bbb;border-radius:24px}
button{padding:10px 18px;border:1px solid #aaa;border-radius:20px;background:#fff;cursor:pointer}
.meta{color:#666;margin:14px 0 22px}.result{margin:0 0 25px}.result h3{margin:0 0 5px;font-size:20px}.result h3 a{text-decoration:none}
.url{color:#27733a;font-size:14px;overflow-wrap:anywhere}.snippet{color:#444;line-height:1.5;margin-top:6px}
.pages{display:flex;gap:6px;flex-wrap:wrap;margin:30px 0}.pages a{padding:8px 12px;border:1px solid #ccc;border-radius:6px;text-decoration:none}
.empty{padding:50px 0;text-align:center;color:#666}"""

def esc(s):
    return (s or "").replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"',"&quot;")

@app.route("/")
def home():
    return """<!doctype html><meta charset=utf-8><title>My Search</title><style>"""+CSS+"""</style>
    <h1>My Search Engine V13</h1>
    <form class=search action=/search><input name=q autofocus placeholder="Search..."><button>Search</button></form>
    <p class=meta>Local index: %s pages, %s terms</p>"""%(stats()["pages"],stats()["terms"])

@app.route("/search")
def search_page():
    q=request.args.get("q","").strip()
    try: page=max(1,int(request.args.get("page","1")))
    except: page=1
    per=20
    results,total=search(q,page,per) if q else ([],0)
    pages=max(1,math.ceil(total/per)) if total else 0
    body=["<!doctype html><meta charset=utf-8><title>Search: "+esc(q)+"</title><style>"+CSS+"</style>",
          f'<form class=search action=/search><input name=q value="{esc(q)}"><button>Search</button></form>']
    if q:
        body.append(f'<div class=meta>{total} matching indexed pages · page {page} of {pages or 0}</div>')
    if not results:
        body.append('<div class=empty>No matching indexed pages found.<br>Try another query or crawl more pages.</div>')
    for x in results:
        body.append(f'<div class=result><h3><a href="{esc(x["url"])}" target="_self">{esc(x["title"])}</a></h3>'
                    f'<div class=url>{esc(x["url"])}</div><div class=snippet>{esc(x["snippet"])}</div></div>')
    if pages:
        nav=[]
        lo=max(1,page-3); hi=min(pages,page+3)
        if page>1: nav.append(f'<a href="/search?q={urllib.parse.quote_plus(q)}&page={page-1}">← Previous</a>')
        for p in range(lo,hi+1):
            nav.append(f'<a href="/search?q={urllib.parse.quote_plus(q)}&page={p}">{p}</a>')
        if page<pages: nav.append(f'<a href="/search?q={urllib.parse.quote_plus(q)}&page={page+1}">Next →</a>')
        body.append('<div class=pages>'+''.join(nav)+'</div>')
    return "".join(body)

@app.route("/api/search")
def api_search():
    q=request.args.get("q","").strip()
    page=max(1,int(request.args.get("page","1")))
    per=min(100,max(1,int(request.args.get("per_page","20"))))
    results,total=search(q,page,per) if q else ([],0)
    return jsonify({"query":q,"page":page,"per_page":per,"total":total,"results":results})

@app.route("/api/suggest")
def suggest():
    p=request.args.get("prefix","").lower().strip()
    if not p:return jsonify([])
    from .db import connect
    c=connect(); rows=c.execute("SELECT term FROM terms WHERE term LIKE ? ORDER BY df DESC LIMIT 10",(p+"%",)).fetchall()
    c.close(); return jsonify([r["term"] for r in rows])

@app.route("/stats")
def stats_page():
    return jsonify(stats())

if __name__=="__main__":
    app.run("127.0.0.1",5000,debug=False,threaded=True)
