from .embeddings import build_embeddings
if __name__=='__main__': build_embeddings()
