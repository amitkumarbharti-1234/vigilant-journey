import time, hashlib, urllib.parse, requests, sqlite3, re
from bs4 import BeautifulSoup
from .config import USER_AGENT, CRAWL_TIMEOUT, MAX_TEXT, DEFAULT_SEEDS
from .db import connect, init_db

def norm(url):
    try:
        p=urllib.parse.urlsplit(url)
        if p.scheme not in ("http","https") or not p.netloc: return None
        host=p.netloc.lower()
        path=p.path or "/"
        return urllib.parse.urlunsplit((p.scheme,host,path,p.query,""))
    except: return None

def allowed(url):
    return urllib.parse.urlsplit(url).netloc.lower()

def seed_frontier(urls=DEFAULT_SEEDS):
    init_db(); c=connect(); now=time.time()
    for u in urls:
        u=norm(u)
        if u:
            c.execute("""INSERT OR IGNORE INTO url_frontier
            (url,status,priority,discovered_at,next_crawl,depth) VALUES(?,?,?,?,?,0)""",
            (u,"queued",100,now,now))
    c.commit(); c.close()

def get_due(limit=100):
    c=connect()
    rows=c.execute("""SELECT * FROM url_frontier
      WHERE status IN ('queued','error') AND (next_crawl IS NULL OR next_crawl<=?)
      ORDER BY priority DESC, discovered_at ASC LIMIT ?""",(time.time(),limit)).fetchall()
    c.close(); return rows

def queue_links(links,depth):
    c=connect(); now=time.time()
    for u,a in links:
        u=norm(u)
        if not u: continue
        c.execute("""INSERT OR IGNORE INTO url_frontier
        (url,status,priority,discovered_at,next_crawl,depth) VALUES(?,?,?,?,?,?)""",
        (u,"queued",max(1,50-depth),now,now,depth))
    c.commit(); c.close()

def crawl_one(row):
    url=row["url"]; depth=row["depth"] or 0
    c=connect(); now=time.time()
    c.execute("UPDATE url_frontier SET status='crawling' WHERE url=?",(url,)); c.commit()
    try:
        r=requests.get(url,headers={"User-Agent":USER_AGENT},timeout=CRAWL_TIMEOUT,
                       allow_redirects=True)
        final=norm(r.url) or url
        ctype=r.headers.get("content-type","").lower()
        if r.status_code>=400 or "text/html" not in ctype:
            c.execute("""UPDATE url_frontier SET status='error',status_code=?,error=?,
                       next_crawl=?,crawl_count=crawl_count+1 WHERE url=?""",
                      (r.status_code,str(r.status_code),now+3600,url))
            c.commit(); c.close(); return 0

        html=r.text[:MAX_TEXT*3]
        soup=BeautifulSoup(html,"html.parser")
        title=soup.title.get_text(" ",strip=True) if soup.title else ""
        h1=" ".join(x.get_text(" ",strip=True) for x in soup.find_all("h1"))[:1000]
        for x in soup(["script","style","noscript","svg"]): x.decompose()
        text=re.sub(r"\s+"," ",soup.get_text(" ",strip=True))[:MAX_TEXT]
        h=hashlib.sha256(text.encode("utf-8","ignore")).hexdigest()
        domain=urllib.parse.urlsplit(final).netloc.lower()

        old=c.execute("SELECT id,content_hash FROM pages WHERE url=?",(final,)).fetchone()
        if old:
            pid=old["id"]
            c.execute("""UPDATE pages SET title=?,h1=?,text=?,domain=?,crawled_at=?,etag=?,
              last_modified=?,content_hash=?,status_code=?,depth=?,content_length=? WHERE id=?""",
              (title,h1,text,domain,now,r.headers.get("ETag"),r.headers.get("Last-Modified"),
               h,r.status_code,depth,len(text),pid))
            c.execute("DELETE FROM links WHERE from_id=?",(pid,))
        else:
            cur=c.execute("""INSERT INTO pages
              (url,title,text,domain,crawled_at,etag,last_modified,content_hash,status_code,depth,content_length)
              VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
              (final,title,text,domain,now,r.headers.get("ETag"),r.headers.get("Last-Modified"),
               h,r.status_code,depth,len(text)))
            pid=cur.lastrowid

        discovered=[]
        for a in soup.find_all("a",href=True):
            u=norm(urllib.parse.urljoin(final,a["href"]))
            if u:
                anchor=re.sub(r"\s+"," ",a.get_text(" ",strip=True))[:200]
                c.execute("INSERT INTO links(from_id,to_url,anchor) VALUES(?,?,?)",(pid,u,anchor))
                discovered.append((u,anchor))
        c.execute("""UPDATE url_frontier SET status='done',crawled_at=?,next_crawl=?,
          status_code=?,error=NULL,content_hash=?,crawl_count=crawl_count+1 WHERE url=?""",
          (now,now+86400,r.status_code,h,url))
        c.commit(); c.close()
        queue_links(discovered,depth+1)
        return 1
    except Exception as e:
        c.execute("""UPDATE url_frontier SET status='error',error=?,next_crawl=?,
          crawl_count=crawl_count+1 WHERE url=?""",(str(e)[:500],now+1800,url))
        c.commit(); c.close(); return 0

def crawl_cycle(max_pages=250):
    init_db()
    if not get_due(1):
        seed_frontier()

    ok = 0
    attempted = 0

    # Re-read the frontier after each batch so links discovered by crawled
    # pages can be crawled during this same command.
    while attempted < max_pages:
        batch = get_due(min(25, max_pages - attempted))
        if not batch:
            break
        for r in batch:
            if attempted >= max_pages:
                break
            attempted += 1
            ok += crawl_one(r)

    return ok, attempted
