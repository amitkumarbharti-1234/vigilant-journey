import re, math
from bs4 import BeautifulSoup
from .config import STOPWORDS

TOKEN_RE=re.compile(r"[A-Za-z0-9][A-Za-z0-9_'-]*")

def tokens(s):
    return [x.lower() for x in TOKEN_RE.findall(s or "")]

def useful_tokens(s):
    return [x for x in tokens(s) if len(x)>1 and x not in STOPWORDS]

def extract(html):
    soup=BeautifulSoup(html,"html.parser")
    for x in soup(["script","style","noscript","svg"]): x.decompose()
    title=soup.title.get_text(" ",strip=True) if soup.title else ""
    text=soup.get_text(" ",strip=True)
    text=re.sub(r"\s+"," ",text)
    return title,text

def phrase_bonus(text,q):
    a=(text or "").lower(); b=" ".join(useful_tokens(q))
    if not b: return 0
    return 8.0 if b in a else 0.0

def title_quality(title):
    t=(title or "").strip()
    if not t: return 0
    return min(1.0, len(t)/60)
