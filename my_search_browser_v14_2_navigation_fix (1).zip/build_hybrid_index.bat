@echo off
python -m search_engine.upgrade_v13
python -m search_engine.rebuild_index
python -m search_engine.pagerank
python -m search_engine.prioritize
python -m search_engine.build_embeddings
python -c "from search_engine.indexer import stats; print(stats())"
pause
