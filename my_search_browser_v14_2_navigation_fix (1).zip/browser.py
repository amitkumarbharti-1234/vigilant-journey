import sys, time, threading, urllib.parse, subprocess
from PySide6.QtCore import QUrl, QTimer
from PySide6.QtWidgets import QApplication, QMainWindow, QLineEdit, QToolBar, QWidget, QVBoxLayout, QToolButton
from PySide6.QtWebEngineWidgets import QWebEngineView

HOME = "http://127.0.0.1:5000/"

LOADING = """<!doctype html>
<html><head><meta charset="utf-8"><title>Searching...</title>
<style>
body{font-family:Arial,sans-serif;background:#fff;color:#222;text-align:center;padding-top:18vh}
.spinner{width:44px;height:44px;border:5px solid #ddd;border-top-color:#333;border-radius:50%;
animation:spin 0.8s linear infinite;margin:0 auto 22px}
@keyframes spin{to{transform:rotate(360deg)}}
h2{font-weight:500} .q{color:#666;font-size:18px}
</style></head><body><div class="spinner"></div><h2>Searching...</h2><div class="q">{}</div></body></html>"""

def start_server():
    import requests
    try:
        r = requests.get(HOME, timeout=0.7)
        if r.status_code:
            return
    except Exception:
        pass
    subprocess.Popen([sys.executable, "-m", "search_engine.server"],
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

class Browser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("My Search Browser V14.1")
        self.resize(1280, 820)

        self.address = QLineEdit()
        self.address.setPlaceholderText("Search the web or enter a URL")
        self.address.returnPressed.connect(self.navigate)

        bar = QToolBar()

        self.back_btn = QToolButton()
        self.back_btn.setText("←")
        self.back_btn.setToolTip("Back")
        self.back_btn.clicked.connect(self.view_back)
        bar.addWidget(self.back_btn)

        self.forward_btn = QToolButton()
        self.forward_btn.setText("→")
        self.forward_btn.setToolTip("Forward")
        self.forward_btn.clicked.connect(self.view_forward)
        bar.addWidget(self.forward_btn)

        self.home_btn = QToolButton()
        self.home_btn.setText("⌂")
        self.home_btn.setToolTip("Home")
        self.home_btn.clicked.connect(lambda: self.view.load(QUrl(HOME)))
        bar.addWidget(self.home_btn)

        bar.addWidget(self.address)
        self.addToolBar(bar)

        self.view = QWebEngineView()
        self.setCentralWidget(self.view)
        self.view.urlChanged.connect(lambda url: self.address.setText(url.toString()))
        self.view.loadProgress.connect(lambda _p: self.update_nav_buttons())
        self.view.loadFinished.connect(lambda _ok: self.update_nav_buttons())
        self.view.titleChanged.connect(self.setWindowTitle)
        self.view.loadStarted.connect(lambda: self.setWindowTitle("Loading..."))
        self.view.loadFinished.connect(lambda ok: self.setWindowTitle(
            self.view.title() if ok and self.view.title() else "My Search Browser V14.1"))

        self.view.setHtml(LOADING.replace("{}", "Starting search server..."))
        QTimer.singleShot(250, lambda: self.view.load(QUrl(HOME)))

    def view_back(self):
        if self.view.history().canGoBack():
            self.view.back()

    def view_forward(self):
        if self.view.history().canGoForward():
            self.view.forward()

    def update_nav_buttons(self):
        history = self.view.history()
        self.back_btn.setEnabled(history.canGoBack())
        self.forward_btn.setEnabled(history.canGoForward())

    def navigate(self):
        raw = self.address.text().strip()
        if not raw:
            return
        if raw.startswith(("http://", "https://")):
            self.view.load(QUrl(raw))
            return
        q = urllib.parse.quote_plus(raw)
        safe_query = raw.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
        self.view.setHtml(LOADING.replace("{}", safe_query))
        QTimer.singleShot(120, lambda: self.view.load(QUrl(f"http://127.0.0.1:5000/search?q={q}&page=1")))

if __name__ == "__main__":
    threading.Thread(target=start_server, daemon=True).start()
    app = QApplication(sys.argv)
    w = Browser()
    w.show()
    sys.exit(app.exec())
