# My Search Browser V13

V13 upgrades:
- Up to 100 results per query
- Pagination
- Better BM25-style lexical ranking
- Phrase matching
- Title/URL/anchor weighting
- PageRank + freshness + content quality signals
- Larger persistent crawler frontier
- Search loading screen in the desktop browser
- Local Flask search server
- Direct URL opening
- Suggestions and spelling support

## Windows setup

```powershell
cd "PATH\TO\my_search_browser_v13"
python -m pip install -r requirements.txt
python -m search_engine.upgrade_v13
python -m search_engine.frontier_cycle --pages 250
python -m search_engine.rebuild_index
python -m search_engine.pagerank
python -m search_engine.prioritize
python -c "from search_engine.indexer import stats; print(stats())"
python browser.py
```

For a larger index, repeat:
```powershell
python -m search_engine.frontier_cycle --pages 1000
python -m search_engine.rebuild_index
python -m search_engine.pagerank
python -m search_engine.prioritize
```

The engine is intentionally a small educational search engine. It will not have Google's web-scale coverage.

## V14 Hybrid Search
- BM25 body relevance
- Title / H1 / URL field weighting
- Phrase matching and anchor evidence
- Local semantic/vector embeddings using all-MiniLM-L6-v2
- Hybrid score combining BM25 + semantic similarity + PageRank
- Run `python -m search_engine.build_embeddings` after rebuilding the index.
